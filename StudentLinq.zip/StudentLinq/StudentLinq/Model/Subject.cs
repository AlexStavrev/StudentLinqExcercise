﻿namespace StudentLinq.Model
{
    public enum Subject { Physics, Cooking, Programming, Juggling, Litterature}
}
