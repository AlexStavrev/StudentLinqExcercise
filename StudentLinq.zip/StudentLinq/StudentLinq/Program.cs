﻿using System;
using System.Linq;

namespace StudentLinq
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("All students");
            DataAccess.GetAllStudents().ToList().ForEach(Console.WriteLine);
            Console.WriteLine();

            
            Console.WriteLine("Firstname of all students");
            //your code here
            Console.WriteLine();

            
            Console.WriteLine("All students, sorted by last name");
            //your code here
            Console.WriteLine();

            
            Console.WriteLine("All students, sorted descending by number of courses taken");
            //your code here
            Console.WriteLine();


            Console.WriteLine("Email addresses of all students who have scored 100 on a test");
            //your code here
            Console.WriteLine();


            Console.WriteLine("All students who have an average above 75 on their tests");
            //your code here
            Console.WriteLine();


            Console.WriteLine("Firstname and average from all students who have an average above 75 on their tests");
            //your code here
            Console.WriteLine();


            Console.WriteLine("All students who have taken an intermediate/advanced class (one without '101' in the name)");
            //your code here
            Console.WriteLine();

        }
    }
}